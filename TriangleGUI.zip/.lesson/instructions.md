# Introduction
In this assignment, you will create an application with a functional GUI (Graphical User Interface) that makes use of the TriangleClassifier.java class that you previously created. This will serve as an introduction to the use of the WindowBuilder plug-in available in Eclipse, and to the Swing library of graphical controls.

# Deliverable

- Create the following interface exactly as shown:
![TC](TriangleClassifier.jpg)

  - TriangleClassifier
  - Size is 220 x 165 pixels
  - Title is "TC" (unfortunately, we cannot put a more descriptive name in the title!)
  - Ensure that you use appropriate naming conventions (including Hungarian prefixes for your control names!)
- Add an event handler to the "Calculate" button.
  - Within this event handler, read the values from the three input text boxes, calculate the classification of the triangle, and output the result to the output text box
  - You do not need to provide validation... yet!
  
**Note:** Please see Java Swing Tutorial 1 code and powerpoint