class Main {
  public static void main(String[] args) {
    //You can create your GUI here, but upload your original TriangleClassifier.java file here as well.
    TriangleClassifierGUI.main(args);
  }
}