//imports
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class TriangleClassifierGUI extends JFrame{
  private JPanel contentPane;
  private JTextField textFieldOne;
  private JTextField textFieldTwo;
  private JTextField textFieldThree;
  private JLabel lblResult;
  //launches application
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          TriangleClassifierGUI frame = new TriangleClassifierGUI();
          frame.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }
  //create window
  public TriangleClassifierGUI(){
    //title of window
    setTitle("TC");
    //exit button operated by mouse
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //window dimensions
    setBounds(0, 0, 300, 450);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    contentPane.setLayout(null);
    setContentPane(contentPane);
    //placement of "Angle A"
    JLabel lblNumberOne = new JLabel ("Angle A");
    lblNumberOne.setBounds(20,45,200,40);
    contentPane.add(lblNumberOne);
    //placement of "Angle B"
    JLabel lblNumberTwo = new JLabel ("Angle B");
    lblNumberTwo.setBounds(20,85,200,40);
    contentPane.add(lblNumberTwo);
    //placement of "Angle C"
    JLabel lblNumberThree = new JLabel ("Angle C");
    lblNumberThree.setBounds(20,125,200,40);
    contentPane.add(lblNumberThree);
    //textbox placement for Angle A
    textFieldOne = new JTextField();
    textFieldOne.setBounds(100,45,100,45);
    textFieldOne.setColumns(10);
    contentPane.add(textFieldOne);
    //textbox placement for Angle A
    textFieldTwo = new JTextField();
    textFieldTwo.setBounds(100,85,100,45);
    textFieldTwo.setColumns(10);
    contentPane.add(textFieldTwo);
    //textbox placement for Angle A
    textFieldThree = new JTextField();
    textFieldThree.setBounds(100,125,100,45);
    textFieldThree.setColumns(10);
    contentPane.add(textFieldThree);
    //classify button for calssification of angles
    JButton btnClassify = new JButton("Classify");
    btnClassify.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e) {
        calculate();
      }
    });
    //placement of "Classify" button
    btnClassify.setBounds(100, 200, 100, 25);
    contentPane.add(btnClassify);
    lblResult = new JLabel("");
    //placement of classification or error statement
    lblResult.setBounds(10,200,300,100);
    lblResult.setHorizontalAlignment(JTextField.CENTER);
    contentPane.add(lblResult);
  }
  //return statement
  public void calculate(){
    try{
      TriangleClassifier result = new TriangleClassifier();
      int angleA = Integer.valueOf(textFieldOne.getText());
      int angleB = Integer.valueOf(textFieldTwo.getText());
      int angleC = Integer.valueOf(textFieldThree.getText());
      //if inputs are valid, return statement = black
      lblResult.setForeground(Color.BLACK);
      lblResult.setText(result.getClassification(angleA,angleB,angleC));
    }catch(NumberFormatException e){
      //if inputs are invalid, return statement = red
      lblResult.setForeground(Color.RED);
      //error statement
      lblResult.setText("Invalid input! Integers only.");
    }
  }
}