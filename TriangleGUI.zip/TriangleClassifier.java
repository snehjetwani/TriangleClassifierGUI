public class TriangleClassifier{
  //Create getClassification method here, make sure it returns a String type.
  public String getClassification(int angleA, int angleB, int angleC){ 
    int sum = angleA + angleB + angleC;
    // Sum of all 3 angles
    String typeOfTriangle = "";
    String anglesOfTriangle = "";
    // Making the variable for the final statement of the code
   if(sum != 180){
     return "INVALID";
    // If the angles do not add up to 180, the triangle doesn't exist
  }if(angleA == 0 || angleB == 0 || angleC == 0){
     return "INVALID";
    // 0 degree angles can't exist in a triangle
  }if(angleA == 60 && angleB == 60 && angleC == 60){
     return "equilateral";
     // If all 3 agles are 60 degrees, the trianle is equilateral
  }if(angleA > 90 || angleB > 90 || angleC > 90){
     typeOfTriangle = "obtuse";
     // If one angle is above 90 degrees, then the triangle is obtuse
  }if(angleA < 90 && angleB < 90 && angleC < 90){
     typeOfTriangle = "acute";
     // All 3 angles must be below 90 degrees in order to be acute
  }if(angleA == 90 || angleB == 90 || angleC == 90){
     typeOfTriangle = "right";
     // If one angle is 90 degrees, the triangle is right
  }if(angleA != angleB && angleB != angleC && angleA != angleC){
     anglesOfTriangle = "scalene";
     // If none of the angles are equivalent to one another, the triangle is scalene
  }if(angleA == angleB || angleB == angleC || angleA == angleC){
     anglesOfTriangle = "isosceles";
     // If 2 angles are equivalent to one another, the triangle is isosceles
  }
   return typeOfTriangle + " " + anglesOfTriangle;
  }
}
